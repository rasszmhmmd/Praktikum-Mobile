import 'package:flutter/material.dart';
import '../models/product.dart';

class ProductProvider with ChangeNotifier {
  List<Product> _items = [
    Product(
      id: 'p1',
      title: 'Red Shirt',
      description: 'A red shirt - it is pretty red!',
      price: 29.99,
      imageUrl: 'https://via.placeholder.com/150',
    ),
    Product(
      id: 'p2',
      title: 'Blue Jeans',
      description: 'A nice pair of blue jeans.',
      price: 59.99,
      imageUrl: 'https://via.placeholder.com/150',
    ),
    Product(
      id: 'p3',
      title: 'Yellow Scarf',
      description: 'A warm and cozy yellow scarf.',
      price: 19.99,
      imageUrl: 'https://via.placeholder.com/150',
    ),
    Product(
      id: 'p4',
      title: 'Green Hat',
      description: 'A stylish green hat.',
      price: 14.99,
      imageUrl: 'https://via.placeholder.com/150',
    ),
    Product(
      id: 'p5',
      title: 'Black Shoes',
      description: 'Comfortable black shoes.',
      price: 79.99,
      imageUrl: 'https://via.placeholder.com/150',
    ),
    Product(
      id: 'p6',
      title: 'White T-shirt',
      description: 'A plain white t-shirt.',
      price: 9.99,
      imageUrl: 'https://via.placeholder.com/150',
    ),
    Product(
      id: 'p7',
      title: 'Purple Jacket',
      description: 'A warm purple jacket.',
      price: 89.99,
      imageUrl: 'https://via.placeholder.com/150',
    ),
    Product(
      id: 'p8',
      title: 'Orange Socks',
      description: 'A pair of orange socks.',
      price: 4.99,
      imageUrl: 'https://via.placeholder.com/150',
    ),
  ];

  List<Product> get items {
    return [..._items];
  }

  Product findById(String id) {
    return _items.firstWhere((prod) => prod.id == id);
  }
}
