import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../widgets/product_grid.dart';
import '../providers/product_provider.dart';
import '../screens/cart_screen.dart';

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('E-Commerce App'),
        actions: <Widget>[
          IconButton(
            icon: Icon(Icons.search),
            onPressed: () {},
          ),
          IconButton(
            icon: Icon(Icons.filter_list),
            onPressed: () {},
          ),
        ],
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: <Widget>[
            DrawerHeader(
              child: Text('Menu'),
              decoration: BoxDecoration(
                color: Colors.blue,
              ),
            ),
            ListTile(
              title: Text('Featured'),
              onTap: () {},
            ),
            ListTile(
              title: Text('Apartment'),
              onTap: () {},
            ),
            ListTile(
              title: Text('Accessories'),
              onTap: () {},
            ),
            ListTile(
              title: Text('Shoes'),
              onTap: () {},
            ),
            ListTile(
              title: Text('Tops'),
              onTap: () {},
            ),
            ListTile(
              title: Text('Bottoms'),
              onTap: () {},
            ),
            ListTile(
              title: Text('Dresses'),
              onTap: () {},
            ),
            ListTile(
              title: Text('My Account'),
              onTap: () {},
            ),
          ],
        ),
      ),
      body: ProductGrid(),
      floatingActionButton: FloatingActionButton(
        child: Icon(Icons.shopping_cart),
        onPressed: () {
          Navigator.of(context).pushNamed(CartScreen.routeName);
        },
      ),
    );
  }
}
